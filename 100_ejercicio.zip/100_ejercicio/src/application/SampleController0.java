package application;

public class SampleController0 {
	
}
